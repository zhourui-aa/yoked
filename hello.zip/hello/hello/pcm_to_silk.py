#!/usr/bin/env python3
"""PCM（stdin）→ SILK（stdout）"""
import sys, tempfile, os, pilk

pcm = sys.stdin.buffer.read()
sample_rate = int(sys.argv[1]) if len(sys.argv) > 1 else 16000

# pilk C 扩展只认文件路径
pcm_file = tempfile.NamedTemporaryFile(suffix='.pcm', delete=False)
silk_file = tempfile.NamedTemporaryFile(suffix='.silk', delete=False)
try:
    pcm_file.write(pcm)
    pcm_file.close()
    silk_file.close()

    pilk.encode(pcm_file.name, silk_file.name, sample_rate, 24000)

    with open(silk_file.name, 'rb') as f:
        sys.stdout.buffer.write(f.read())
finally:
    os.unlink(pcm_file.name)
    os.unlink(silk_file.name)
