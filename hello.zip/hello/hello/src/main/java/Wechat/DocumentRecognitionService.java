package Wechat;

import org.apache.pdfbox.Loader;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.poi.xwpf.extractor.XWPFWordExtractor;
import org.apache.poi.xwpf.usermodel.XWPFDocument;

import java.io.*;

/**
 * 文档识别服务 —— 从文件提取文字
 *
 * 支持 PDF / DOCX / TXT
 */
public class DocumentRecognitionService {

    /**
     * 根据文件名和字节提取文字
     */
    public String extractText(byte[] fileBytes, String fileName) {
        if (fileName == null) return null;
        String lower = fileName.toLowerCase();

        try {
            if (lower.endsWith(".pdf")) {
                return extractPdf(fileBytes);
            } else if (lower.endsWith(".docx")) {
                return extractDocx(fileBytes);
            } else if (lower.endsWith(".txt") || lower.endsWith(".md")) {
                return extractTxt(fileBytes);
            } else {
                return null;  // 不支持的类型
            }
        } catch (Exception e) {
            System.err.println("[DocRec] 提取失败: " + fileName + " - " + e.getMessage());
            return null;
        }
    }

    private String extractPdf(byte[] bytes) throws IOException {
        try (var doc = Loader.loadPDF(bytes)) {
            var stripper = new PDFTextStripper();
            stripper.setSortByPosition(true);
            String text = stripper.getText(doc);
            System.out.println("[DocRec] PDF: " + text.length() + " 字符");
            return text.trim();
        }
    }

    private String extractDocx(byte[] bytes) throws IOException {
        try (var is = new ByteArrayInputStream(bytes);
             var doc = new XWPFDocument(is);
             var extractor = new XWPFWordExtractor(doc)) {
            String text = extractor.getText();
            System.out.println("[DocRec] DOCX: " + text.length() + " 字符");
            return text.trim();
        }
    }

    private String extractTxt(byte[] bytes) {
        String text = new String(bytes, java.nio.charset.StandardCharsets.UTF_8);
        System.out.println("[DocRec] TXT: " + text.length() + " 字符");
        return text.trim();
    }
}
