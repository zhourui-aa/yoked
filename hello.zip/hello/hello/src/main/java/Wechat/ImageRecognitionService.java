package Wechat;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

import java.util.*;

/**
 * 阿里云百炼 图片识别服务（千问 Qwen-VL 多模态模型）
 *
 * 接口：DashScope 多模态对话
 * 端点：compatible-mode/v1（OpenAI 兼容，省事）
 */
public class ImageRecognitionService {

    // OpenAI 兼容端点
    private static final String API_URL = Config.aliyunApiUrl();
    private static final String MODEL = "qwen-vl-plus";
    private static final String API_KEY = Config.aliyunApiKey();

    private final RestTemplate restTemplate = new RestTemplate();
    private final ObjectMapper objectMapper = new ObjectMapper();

    public String recognize(byte[] imageBytes, String prompt) {
        try {
            System.out.println("[ImageRecognition] 收到图片: " + imageBytes.length + " 字节");//日志
            String base64 = Base64.getEncoder().encodeToString(imageBytes);//转化成base64
            String dataUrl = "data:image/jpeg;base64," + base64;
            System.out.println("[ImageRecognition] DataURL 长度: " + dataUrl.length());

            // OpenAI 兼容格式: content 数组
            //构建请求体，给ai完整命令行
            List<ContentPart> content = new ArrayList<>();
            content.add(new ContentPart("text", prompt != null ? prompt : "请描述这张图片"));
            content.add(new ContentPart("image_url", new ImageUrlObj(dataUrl)));

            VisionMessage msg = new VisionMessage();
            msg.role = "user";
            msg.content = content;

            VisionRequest request = new VisionRequest();
            request.model = MODEL;
            request.messages = Collections.singletonList(msg);


            //发送http请求


            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set("Authorization", "Bearer " + API_KEY);

            String body = objectMapper.writeValueAsString(request);
            HttpEntity<String> entity = new HttpEntity<>(body, headers);

            //处理响应

            //看看ai有没有识别成功
            ResponseEntity<String> resp = restTemplate.exchange(API_URL, HttpMethod.POST, entity, String.class);
            System.out.println("[ImageRecognition] HTTP " + resp.getStatusCode());

            String respBody = resp.getBody();
            if (respBody != null && respBody.contains("\"error\"")) {
                System.out.println("[ImageRecognition] 错误: " + respBody.substring(0, Math.min(500, respBody.length())));
                throw new RuntimeException("阿里云返回错误");
            }

            VisionResponse vr = objectMapper.readValue(respBody, VisionResponse.class);
            if (vr.choices == null || vr.choices.isEmpty()) {
                throw new RuntimeException("返回空 choices");
            }
            return vr.choices.get(0).message.content;

        } catch (Exception e) {
            System.err.println("[ImageRecognition] 失败: " + e.getMessage());
            return "图片识别失败: " + e.getMessage();
        }
    }

    // ==================== OpenAI 兼容格式模型 ====================

    static class ContentPart {
        public String type;
        public String text;
        public ImageUrlObj image_url;

        ContentPart() {}
        ContentPart(String type, String text) { this.type = type; this.text = text; }
        ContentPart(String type, ImageUrlObj img) { this.type = type; this.image_url = img; }
    }

    static class ImageUrlObj {
        public String url;
        ImageUrlObj() {}
        ImageUrlObj(String url) { this.url = url; }
    }

    static class VisionMessage {
        public String role;
        public List<ContentPart> content;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class VisionRequest {
        public String model;
        public List<VisionMessage> messages;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class VisionResponse {
        public List<Choice> choices;

        @JsonIgnoreProperties(ignoreUnknown = true)
        static class Choice {
            public Message message;
        }

        @JsonIgnoreProperties(ignoreUnknown = true)
        static class Message {
            public String content;
        }
    }
}
