package Wechat;

import org.springframework.core.io.ClassPathResource;

import java.io.InputStream;
import java.util.Properties;

/**
 * 统一配置读取 —— 所有 Key 和敏感信息从 application.properties 加载
 */
public class Config {

    private static final Properties props = new Properties();

    static {
        try (InputStream in = new ClassPathResource("application.properties").getInputStream()) {
            props.load(in);
        } catch (Exception e) {
            throw new RuntimeException("加载 application.properties 失败", e);
        }
    }

    public static String get(String key) {
        return props.getProperty(key);
    }

    // ==================== 和风天气 ====================
    public static String weatherApiUrl()  { return get("weather.api.url"); }
    public static String weatherApiKey()  { return get("weather.api.key"); }

    // ==================== DeepSeek ====================
    public static String deepseekApiUrl() { return get("deepseek.api.url"); }
    public static String deepseekApiKey() { return get("deepseek.api.key"); }

    // ==================== 阿里云 ====================
    public static String aliyunApiUrl()   { return get("aliyun.api.url"); }
    public static String aliyunApiKey()   { return get("aliyun.api.key"); }

    // ==================== 阿里云语音 ====================
    public static String aliyunAsrUrl()   { return get("aliyun.asr.url"); }
    public static String aliyunTtsUrl()   { return get("aliyun.tts.url"); }
}
