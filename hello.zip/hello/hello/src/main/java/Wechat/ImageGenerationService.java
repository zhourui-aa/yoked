package Wechat;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.*;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.springframework.web.client.RestTemplate;

import java.util.List;

/**
 * 阿里云百炼 图片生成服务（通义万相 Wanx）
 *
 * 异步流程：提交任务 → 拿 task_id → 轮询结果 → 下载图片
 */
public class ImageGenerationService {

    private static final String API_URL = "https://dashscope.aliyuncs.com/api/v1/services/aigc/text2image/image-synthesis";
    private static final String TASK_URL = "https://dashscope.aliyuncs.com/api/v1/tasks/";
    private static final String MODEL = "wan2.2-t2i-flash";
    private static final String API_KEY = Config.aliyunApiKey();

    private final RestTemplate restTemplate = new RestTemplate();
    private final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * 根据文字描述生成图片，返回图片字节
     */
    public byte[] generate(String prompt) throws Exception {
        System.out.println("[ImageGen] 生成图片: " + prompt);

        // ──── 第1步：提交异步任务 ────
        GenRequest request = new GenRequest();
        request.model = MODEL;
        request.input = new GenInput(prompt);
        request.parameters = new GenParams();

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization", "Bearer " + API_KEY);
        headers.set("X-DashScope-Async", "enable");  // 异步模式

        String body = objectMapper.writeValueAsString(request);
        System.out.println("[ImageGen] 提交任务...");
        HttpEntity<String> entity = new HttpEntity<>(body, headers);

        ResponseEntity<String> resp = restTemplate.exchange(API_URL, HttpMethod.POST, entity, String.class);
        String respBody = resp.getBody();
        System.out.println("[ImageGen] 提交响应: " + (respBody != null ? respBody.substring(0, Math.min(300, respBody.length())) : "null"));

        // 提取 task_id
        TaskResponse tr = objectMapper.readValue(respBody, TaskResponse.class);
        if (tr.output == null || tr.output.taskId == null) {
            throw new RuntimeException("未获取到 task_id，响应: " + respBody);
        }
        String taskId = tr.output.taskId;
        System.out.println("[ImageGen] task_id: " + taskId);

        // ──── 第2步：轮询任务结果 ────
        String imageUrl = null;
        for (int i = 0; i < 30; i++) {   // 最多等 60 秒
            Thread.sleep(2000);
            HttpHeaders pollHeaders = new HttpHeaders();
            pollHeaders.set("Authorization", "Bearer " + API_KEY);
            ResponseEntity<String> taskResp = restTemplate.exchange(
                    TASK_URL + taskId, HttpMethod.GET,
                    new HttpEntity<>(pollHeaders), String.class);
            String taskBody = taskResp.getBody();
            System.out.println("[ImageGen] 轮询 " + (i + 1) + ": " +
                    (taskBody != null ? taskBody.substring(0, Math.min(200, taskBody.length())) : "null"));

            TaskResult result = objectMapper.readValue(taskBody, TaskResult.class);
            if ("SUCCEEDED".equals(result.output.taskStatus)) {
                // 拿到图片 URL
                imageUrl = result.output.results.get(0).url;
                System.out.println("[ImageGen] 生成成功: " + imageUrl);
                break;
            }
            if ("FAILED".equals(result.output.taskStatus)) {
                String errMsg = result.output.message;
                if (errMsg != null && errMsg.contains("inappropriate")) {
                    throw new ContentSafetyException("内容安全审核未通过，请换个描述方式试试～");
                }
                throw new RuntimeException("生成失败: " + errMsg);
            }
            // 否则还是 RUNNING/PENDING，继续等
        }

        if (imageUrl == null) {
            throw new RuntimeException("生成超时，task_id: " + taskId);
        }

        // ──── 第3步：下载图片（URL 已带签名，裸 GET 就行）───
        System.out.println("[ImageGen] 下载图片: " + imageUrl);
        java.net.URL url = new java.net.URL(imageUrl);
        java.net.HttpURLConnection conn = (java.net.HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setConnectTimeout(10000);
        conn.setReadTimeout(30000);
        java.io.InputStream is = conn.getInputStream();
        byte[] imgBytes = is.readAllBytes();
        is.close();
        conn.disconnect();
        System.out.println("[ImageGen] 下载成功: " + imgBytes.length + " 字节");
        return imgBytes;
    }

    // ==================== 请求/响应模型 ====================

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class GenRequest {
        public String model;
        public GenInput input;
        public GenParams parameters;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class GenInput {
        public String prompt;
        GenInput() {}
        GenInput(String prompt) { this.prompt = prompt; }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class GenParams {
        public String size = "1024*1024";
        public int n = 1;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class TaskResponse {
        public TaskOutput output;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class TaskOutput {
        @JsonProperty("task_id")
        public String taskId;
        @JsonProperty("task_status")
        public String taskStatus;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class TaskResult {
        public ResultOutput output;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class ResultOutput {
        @JsonProperty("task_status")
        public String taskStatus;
        public String message;
        public List<ResultImage> results;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class ResultImage {
        public String url;
    }

    /**
     * 内容安全拦截异常 —— 提示词触发了安全审核
     */
    public static class ContentSafetyException extends RuntimeException {
        public ContentSafetyException(String message) {
            super(message);
        }
    }
}
