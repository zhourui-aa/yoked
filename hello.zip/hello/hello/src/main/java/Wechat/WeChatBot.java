package Wechat;

import com.github.wechat.ilink.sdk.ILinkClient;
import com.github.wechat.ilink.sdk.core.config.ILinkConfig;
import com.github.wechat.ilink.sdk.core.listener.OnLoginListener;
import com.github.wechat.ilink.sdk.core.login.LoginContext;
import com.github.wechat.ilink.sdk.core.model.MessageItem;
import com.github.wechat.ilink.sdk.core.model.WeixinMessage;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * 天气查询微信机器人 —— 基于微信 iLink Bot SDK
 *
 * 用法：运行 main 方法，扫码登录，然后微信发"北京天气"即可查询
 */
public class WeChatBot {

    private static final ChatService deepSeekService = new ChatService();
    private static final ImageRecognitionService imageRecognitionService = new ImageRecognitionService();
    private static final VoiceRecognitionService voiceService = new VoiceRecognitionService();
    private static final VoiceGenerationService voiceGenService = new VoiceGenerationService();
    private static final DocumentRecognitionService docService = new DocumentRecognitionService();

    // 待选音色的语音请求：userId → 问题文本
    private static final Map<String, String> pendingVoiceQuestion = new HashMap<>();

    // 缓存用户最后一次发送的图片 + 识别结果（用于追问时重新分析）
    private static final Map<String, byte[]> lastImageCache = new HashMap<>();
    private static final Map<String, String> lastImageDescCache = new HashMap<>();

    // 追问关键词（表示用户想针对图片深入提问）
    private static final Pattern FOLLOW_UP_PATTERN = Pattern.compile(
        "怎么|什么样|什么|颜色|多大|几个|多少|哪里|在哪|怎么|如何|是不是|有没有|再.*看|仔细|详细|具体"
    );

    // 持有 client 引用，解决 lambda 中未初始化问题
    private static ILinkClient client;

    // 已处理的消息ID集合，防止重复回复
    private static final Set<String> processedMsgIds = new HashSet<>();

    public static void main(String[] args) throws Exception {
        System.out.println("========== 天气查询微信机器人 ==========");

        // 1. 构建配置
        // 只是配置，并不干活 —— 就像调参数，设超时、重试次数、心跳间隔等
        ILinkConfig config = ILinkConfig.builder()
            .connectTimeoutMs(35000)                            // 连接微信服务器超时：35秒
            .readTimeoutMs(35000)                               // 读取响应超时：35秒
            .httpMaxRetries(3)                                  // HTTP请求失败自动重试3次
            .heartbeatEnabled(true)                             // 开启心跳保活，防止连接被服务器断开
            .heartbeatIntervalMs(30000)                         // 每30秒发一次心跳
            .build();


        // 2. 创建客户端（真正干活的），把配置注入进去，绑定三个事件监听器
        client = ILinkClient.builder()
            .config(config)
            // ──── 登录监听器：扫码成功/失败时触发 ────
            .onLogin(new OnLoginListener() {
                @Override
                public void onLoginSuccess(LoginContext ctx) {
                    // 扫码成功 → 拿到 LoginContext(含botToken/userId/botId/baseUrl)
                    System.out.println("✅ 登录成功！botId = " + ctx.getBotId());
                }

                @Override
                public void onLoginFailure(Throwable t) {
                    // 扫码失败/登录超时 → 打印错误，程序继续等待重新登录
                    System.err.println("❌ 登录失败: " + t.getMessage());
                }
            })
            // ──── 心跳监听器：定时向微信服务器发心跳包，维持长连接不被断开 ────
            .onHeartbeat(new com.github.wechat.ilink.sdk.core.listener.OnHeartbeatListener() {
                @Override
                public void onHeartbeatSuccess() {
                    // 心跳成功 → 连接正常，什么都不用做
                    // SDK内部定时(30秒)自动发送，无需手动干预
                }

                @Override
                public void onHeartbeatFailure(Throwable throwable) {
                    // 心跳失败 → 网络断了或服务器挂了
                    // 打印警告方便排查，SDK会自动重试恢复连接
                    System.err.println("💔 心跳失败，连接可能出现问题: " + throwable.getMessage());
                }
            })
            .build();

        // 3. 发起登录，获取二维码
        String qrcodeUrl = client.executeLogin();
        System.out.println("📱 请扫描二维码登录...");
        System.out.println("链接: " + qrcodeUrl);
        System.out.println();

        // 尝试用终端显示二维码
        printQrCode(qrcodeUrl);

        // 4. 等待扫码完成
        System.out.println("等待扫码中...\n");
        client.getLoginFuture().get();

        // 5. 启动轮询，每 2 秒拉取新消息
        System.out.println("🤖 机器人已就绪，按 Ctrl+C 退出\n");
        startPolling();

        // 6. 保持运行，让线程永不退出
        Thread.currentThread().join();
    }

    /**
     * 轮询线程，每 2 秒拉一次新消息（已处理的消息不会重复回复）
     */
    private static void startPolling() {
        Thread poller = new Thread(() -> {//lambda表达式
            while (client != null && client.isLoggedIn()) {//判断客户端是否存在
                try {
                    List<WeixinMessage> messages = client.getUpdates();//拉消息——调 SDK 的方法，向微信服务器请求"最近有没有人给我发新消息"。
                    if (messages != null && !messages.isEmpty()) {
                        handleMessages(client, messages);
                    }
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    break;
                } catch (Exception e) {
                    System.err.println("轮询异常: " + e.getMessage());
                    try { Thread.sleep(5000); } catch (InterruptedException ignored) { break; }
                }
            }
        }, "msg-poller");
        poller.setDaemon(true);
        poller.start();
    }

    /**
     * 处理收到的微信消息
     */
    private static void handleMessages(ILinkClient client, List<WeixinMessage> messages) {
        System.out.println("[DEBUG] handleMessages 收到 " + messages.size() + " 条消息");
        for (WeixinMessage msg : messages) {
            System.out.println("[DEBUG] === 新消息 ===");
            System.out.println("[DEBUG] message_id=" + msg.getMessage_id()
                + " from_user_id=" + msg.getFrom_user_id());
            System.out.println("[DEBUG] create_time_ms=" + msg.getCreate_time_ms());

            // 打印所有 item 的类型
            List<MessageItem> itemList = msg.getItem_list();
            if (itemList != null) {
                for (int i = 0; i < itemList.size(); i++) {
                    MessageItem mi = itemList.get(i);
                    System.out.println("[DEBUG]   item[" + i + "] type=" + mi.getType()
                        + " hasText=" + (mi.getText_item() != null)
                        + " hasImage=" + (mi.getImage_item() != null)
                        + " hasVoice=" + (mi.getVoice_item() != null)
                        + " hasVideo=" + (mi.getVideo_item() != null)
                        + " hasFile=" + (mi.getFile_item() != null));
                    if (mi.getText_item() != null) {
                        System.out.println("[DEBUG]   item[" + i + "] text=" + mi.getText_item().getText());
                    }
                }
            }

            // 去重
            Long msgId = msg.getMessage_id();
            String dedupKey = msg.getFrom_user_id() + ":" + (msgId != null ? msgId : msg.hashCode());
            if (!processedMsgIds.add(dedupKey)) {
                System.out.println("[DEBUG] 去重：跳过已处理消息");
                continue;
            }

            if (processedMsgIds.size() > 500) {
                processedMsgIds.clear();
            }

            String fromUserId = msg.getFrom_user_id();
            String contextToken = msg.getContext_token();

            // ① 先检查图片
            byte[] imageBytes = extractImage(msg);
            if (imageBytes != null) {
                System.out.println("[DEBUG] 路由 → 图片识别");
                String reply = imageRecognitionService.recognize(imageBytes, "请描述这张图片的内容");
                // 缓存原图和描述，方便后续追问
                lastImageCache.put(fromUserId, imageBytes);
                lastImageDescCache.put(fromUserId, reply);
                // 注入对话历史
                deepSeekService.injectImageContext(fromUserId, reply);
                sendReply(client, fromUserId, contextToken, reply);
                continue;
            }

            // ①.3 检查文件（文档识别）
            byte[] fileBytes = extractFile(msg);
            String docFileName = extractFileName(msg);
            if (fileBytes != null && docFileName != null) {
                System.out.println("[DEBUG] 路由 → 文档识别: " + docFileName);
                String docText = docService.extractText(fileBytes, docFileName);
                if (docText == null || docText.isBlank()) {
                    sendReply(client, fromUserId, contextToken,
                        "暂不支持此文件格式，请发送 PDF、Word 或 TXT 文件～");
                } else {
                    // 太长截断（DeepSeek 有 token 限制）
                    String toSummarize = docText.length() > 6000 ? docText.substring(0, 6000) : docText;
                    String summary = deepSeekService.chat(fromUserId,
                        "请总结以下文档内容，用简洁的中文概括要点：\n\n" + toSummarize).text;
                    sendReply(client, fromUserId, contextToken, "📄 " + summary);
                }
                continue;
            }

            // ①.5 检查语音
            byte[] voiceBytes = extractVoice(msg);
            if (voiceBytes != null) {
                Integer voiceSampleRate = extractVoiceSampleRate(msg);
                System.out.println("[DEBUG] 路由 → 语音识别, sample_rate=" + voiceSampleRate);
                int sr = voiceSampleRate != null ? voiceSampleRate : 24000;
                String voiceText = voiceService.speechToText(voiceBytes, "silk", sr);
                if (voiceText == null || voiceText.isBlank()) {
                    sendReply(client, fromUserId, contextToken, "抱歉，我没听清你说什么～");
                    continue;
                }
                System.out.println("[DEBUG] ASR 识别: " + voiceText);

                // Step 2: 文字 → AI 对话（语音场景要求不用 emoji）
                String aiReply = deepSeekService.chat(fromUserId,
                    "[语音消息] " + voiceText + "（注意：回复控制在100字以内，不要使用任何表情符号/emoji）").text;
                System.out.println("[DEBUG] AI 回复: " + aiReply);

                // Step 3: 文字 → MP3 文件
                byte[] replyAudio = voiceGenService.textToSpeech(aiReply);
                if (replyAudio != null) {
                    try {
                        client.sendFile(fromUserId, replyAudio, "语音回复.mp3", "");
                        System.out.println("[DEBUG] MP3 文件已发送: " + replyAudio.length + "字节");
                    } catch (java.io.IOException e) {
                        System.err.println("[DEBUG] 文件发送失败: " + e.getMessage());
                        sendReply(client, fromUserId, contextToken, aiReply);
                    }
                } else {
                    System.out.println("[DEBUG] TTS 失败，仅发送了文字回复");
                    sendReply(client, fromUserId, contextToken, aiReply);
                }
                continue;
            }

            // ② 提取文本
            String text = extractText(msg);
            if (text == null || text.isBlank()) {
                System.out.println("[DEBUG] 无文本无图片，跳过");
                continue;
            }

            System.out.println("[DEBUG] 路由 → ChatService");
            System.out.println("📩 [" + fromUserId + "]: " + text);

            // 去掉 @机器人 等前缀
            String cleanedText = text.replaceAll("@\\S+", "").trim();

            // ========== ② 文本路由 ==========
            String reply;

            if (isFollowUpQuery(cleanedText) && lastImageCache.containsKey(fromUserId)) {
                // 追问图片内容 → 用缓存的原图 + 新问题重新识别
                System.out.println("[DEBUG] 路由 → 图片追问");
                String newQuestion = "用户追问：「" + cleanedText + "」，上次识别结果是：" + lastImageDescCache.get(fromUserId) + "，请结合图片回答用户的新问题";
                String reply2 = imageRecognitionService.recognize(lastImageCache.get(fromUserId), newQuestion);
                deepSeekService.injectImageContext(fromUserId, reply2);
                lastImageDescCache.put(fromUserId, reply2);
                sendReply(client, fromUserId, contextToken, reply2);

            } else if (pendingVoiceQuestion.containsKey(fromUserId)) {
                // 用户在选音色（保留手动路由，因为涉及多轮交互）
                if (cleanedText.equals("取消") || cleanedText.equals("算了")) {
                    pendingVoiceQuestion.remove(fromUserId);
                    sendReply(client, fromUserId, contextToken, "已取消语音生成～");
                    continue;
                }
                String voice = VoiceGenerationService.matchVoice(cleanedText);
                if (voice == null) {
                    sendReply(client, fromUserId, contextToken,
                        "没认出这个音色，请回复数字1-6或音色名～\n" + VoiceGenerationService.getVoiceMenu());
                } else {
                    String question = pendingVoiceQuestion.remove(fromUserId);
                    System.out.println("[DEBUG] 音色: " + voice + " 问题: " + question);
                    String aiReply = deepSeekService.chat(fromUserId, question).text;
                    byte[] replyAudio = voiceGenService.textToSpeech(aiReply, voice);
                    if (replyAudio != null) {
                        try {
                            client.sendFile(fromUserId, replyAudio, "语音回复.mp3", "");
                        } catch (java.io.IOException e) {
                            sendReply(client, fromUserId, contextToken, aiReply);
                        }
                    } else {
                        sendReply(client, fromUserId, contextToken, aiReply);
                    }
                }

            } else {
                // 其他消息 → ChatService（Function Calling 统一调度）
                ChatService.ChatResult result = deepSeekService.chat(fromUserId, text);
                if ("image".equals(result.binaryType) && result.binary != null) {
                    try {
                        client.sendImage(fromUserId, result.binary, "generated.png", result.text);
                    } catch (java.io.IOException e) {
                        sendReply(client, fromUserId, contextToken, result.text);
                    }
                } else if ("voice".equals(result.binaryType) && result.binary != null) {
                    try {
                        client.sendFile(fromUserId, result.binary, "语音回复.mp3", "");
                    } catch (java.io.IOException e) {
                        sendReply(client, fromUserId, contextToken, result.text);
                    }
                } else {
                    sendReply(client, fromUserId, contextToken, result.text);
                }
            }
        }
    }

    /**
     * 从消息中提取图片字节（image_item → 下载 CDN）
     */
    private static byte[] extractImage(WeixinMessage msg) {
        List<MessageItem> items = msg.getItem_list();
        if (items == null || items.isEmpty()) {
            System.out.println("[extractImage] item_list 为空");
            return null;
        }
        // 遍历所有 item，找第一个图片
        for (int i = 0; i < items.size(); i++) {
            MessageItem item = items.get(i);
            System.out.println("[extractImage] item[" + i + "] type=" + item.getType()
                + " text=" + (item.getText_item() != null)
                + " image=" + (item.getImage_item() != null));
            if (item.getImage_item() != null) {
                try {
                    byte[] bytes = client.downloadImageFromMessageItem(item);
                    System.out.println("[extractImage] 下载成功: " + bytes.length + " 字节");
                    return bytes;
                } catch (Exception e) {
                    System.err.println("[extractImage] 下载图片失败: " + e.getMessage());
                    return null;
                }
            }
        }
        System.out.println("[extractImage] 未找到图片 item");
        return null;
    }

    /**
     * 从消息中提取文件字节（file_item → 下载 CDN）
     */
    private static byte[] extractFile(WeixinMessage msg) {
        List<MessageItem> items = msg.getItem_list();
        if (items == null || items.isEmpty()) return null;
        for (MessageItem item : items) {
            if (item.getFile_item() != null) {
                try {
                    byte[] bytes = client.downloadMediaFromMessageItem(item);
                    System.out.println("[extractFile] 下载成功: " + bytes.length + " 字节");
                    return bytes;
                } catch (Exception e) {
                    System.err.println("[extractFile] 下载失败: " + e.getMessage());
                    return null;
                }
            }
        }
        return null;
    }

    /**
     * 从消息中提取文件名
     */
    private static String extractFileName(WeixinMessage msg) {
        List<MessageItem> items = msg.getItem_list();
        if (items == null || items.isEmpty()) return null;
        for (MessageItem item : items) {
            if (item.getFile_item() != null) {
                return item.getFile_item().getFile_name();
            }
        }
        return null;
    }

    /**
     * 从消息中提取语音字节（voice_item → 下载 CDN）
     */
    private static byte[] extractVoice(WeixinMessage msg) {
        List<MessageItem> items = msg.getItem_list();
        if (items == null || items.isEmpty()) {
            System.out.println("[extractVoice] item_list 为空");
            return null;
        }
        for (int i = 0; i < items.size(); i++) {
            MessageItem item = items.get(i);
            System.out.println("[extractVoice] item[" + i + "] type=" + item.getType()
                + " hasVoice=" + (item.getVoice_item() != null));
            if (item.getVoice_item() != null) {
                try {
                    var vi = item.getVoice_item();
                    System.out.println("[extractVoice] encode_type=" + vi.getEncode_type()
                        + " playtime=" + vi.getPlaytime()
                        + " sample_rate=" + vi.getSample_rate());
                    byte[] bytes = client.downloadVoiceFromMessageItem(item);
                    System.out.println("[extractVoice] 下载成功: " + bytes.length + " 字节");
                    // 打印前 20 字节十六进制，帮助识别格式
                    StringBuilder hex = new StringBuilder();
                    for (int j = 0; j < Math.min(20, bytes.length); j++) {
                        hex.append(String.format("%02x ", bytes[j] & 0xff));
                    }
                    String ascii = new String(bytes, 0, Math.min(20, bytes.length),
                        java.nio.charset.StandardCharsets.US_ASCII)
                        .replaceAll("[^\\x20-\\x7e]", ".");
                    System.out.println("[extractVoice] 前20字节(hex): " + hex);
                    System.out.println("[extractVoice] 前20字节(asc): " + ascii);
                    return bytes;
                } catch (Exception e) {
                    System.err.println("[extractVoice] 下载语音失败: " + e.getMessage());
                    return null;
                }
            }
        }
        System.out.println("[extractVoice] 未找到语音 item");
        return null;
    }

    /**
     * 从消息中提取语音采样率
     */
    private static Integer extractVoiceSampleRate(WeixinMessage msg) {
        List<MessageItem> items = msg.getItem_list();
        if (items == null || items.isEmpty()) return null;
        for (MessageItem item : items) {
            if (item.getVoice_item() != null) {
                return item.getVoice_item().getSample_rate();
            }
        }
        return null;
    }

    /**
     * 从消息中提取文本
     */
    private static String extractText(WeixinMessage msg) {
        List<MessageItem> items = msg.getItem_list();
        if (items == null || items.isEmpty()) return null;
        MessageItem item = items.get(0);
        if (item.getText_item() != null) {
            return item.getText_item().getText();
        }
        return null;
    }

    /**
     * 判断是否为对上一张图片的追问
     */
    private static boolean isFollowUpQuery(String text) {
        return FOLLOW_UP_PATTERN.matcher(text).find();
    }

    /**
     * 尝试在终端打印二维码（需要安装 qrencode: brew install qrencode）
     */
    private static void printQrCode(String url) {
        try {
            Process p = new ProcessBuilder("qrencode", "-t", "ANSIUTF8", "-m", "1", url)
                .redirectErrorStream(true)
                .start();
            p.waitFor();
            if (p.exitValue() == 0) {
                p.getInputStream().transferTo(System.out);
                return;
            }
        } catch (Exception e) {
            // qrencode 不可用，忽略
        }
        System.out.println("💡 提示: brew install qrencode 可在终端显示二维码");
    }

    /**
     * 发送文字回复
     */
    private static void sendReply(ILinkClient client, String userId, String contextToken, String reply) {
        try {
            client.sendText(userId, reply);
            System.out.println("📤 回复: " + reply.replace("\n", " | "));
        } catch (Exception e) {
            System.err.println("回复失败: " + e.getMessage());
        }
    }

    /**
     * 发送语音回复
     *
     * @param client     ILinkClient
     * @param userId     接收用户
     * @param audioBytes MP3 音频字节
     * @param text       语音对应的文字（用于微信语音转录展示）
     */
    private static void sendVoiceReply(ILinkClient client, String userId, byte[] audioBytes, String text) {
        try {
            // 估算播放时长：MP3 16000采样率，约 16KB/秒 → 粗略估算
            int estimatedMs = Math.max(1000, audioBytes.length * 1000 / 2000);
            // sample_rate 传 16000 与 CosyVoice TTS 输出一致
            client.sendVoice(userId, audioBytes, "reply.mp3", estimatedMs, 16000);
            System.out.println("🎤 语音回复: " + text.replace("\n", " | ")
                + " (音频 " + audioBytes.length + " 字节, 约 " + estimatedMs + "ms)");
        } catch (Exception e) {
            System.err.println("语音发送失败: " + e.getMessage());
        }
    }
}
