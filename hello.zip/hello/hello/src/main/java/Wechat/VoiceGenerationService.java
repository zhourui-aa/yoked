package Wechat;

import java.io.*;
import java.util.*;

/**
 * 语音生成服务 —— 文字转语音（Edge TTS 免费，支持多种音色）
 */
public class VoiceGenerationService {

    /** 可选音色列表 */
    public static final List<String> VOICES = List.of(
        "zh-CN-XiaoxiaoNeural",   // 1 女声 温暖
        "zh-CN-XiaoyiNeural",     // 2 女声 活泼
        "zh-CN-YunyangNeural",    // 3 男声 专业
        "zh-CN-YunxiNeural",      // 4 男声 阳光
        "zh-CN-YunjianNeural",    // 5 男声 激情
        "zh-CN-YunxiaNeural"      // 6 男声 可爱
    );

    /** 音色名称映射：数字/中文 → 音色ID */
    private static final Map<String, String> VOICE_MAP = new LinkedHashMap<>();
    static {
        String[][] mapping = {
            {"1", "zh-CN-XiaoxiaoNeural"},  {"女声温暖", "zh-CN-XiaoxiaoNeural"}, {"温暖女声", "zh-CN-XiaoxiaoNeural"}, {"xiaoxiao", "zh-CN-XiaoxiaoNeural"},
            {"2", "zh-CN-XiaoyiNeural"},    {"女生活泼", "zh-CN-XiaoyiNeural"},   {"活泼女声", "zh-CN-XiaoyiNeural"},   {"xiaoyi", "zh-CN-XiaoyiNeural"},
            {"3", "zh-CN-YunyangNeural"},   {"男声专业", "zh-CN-YunyangNeural"},  {"专业男声", "zh-CN-YunyangNeural"},  {"yunyang", "zh-CN-YunyangNeural"},
            {"4", "zh-CN-YunxiNeural"},     {"男声阳光", "zh-CN-YunxiNeural"},    {"阳光男声", "zh-CN-YunxiNeural"},    {"yunxi", "zh-CN-YunxiNeural"},
            {"5", "zh-CN-YunjianNeural"},   {"男声激情", "zh-CN-YunjianNeural"},  {"激情男声", "zh-CN-YunjianNeural"},  {"yunjian", "zh-CN-YunjianNeural"},
            {"6", "zh-CN-YunxiaNeural"},    {"男声可爱", "zh-CN-YunxiaNeural"},   {"可爱男声", "zh-CN-YunxiaNeural"},   {"yunxia", "zh-CN-YunxiaNeural"},
        };
        for (String[] m : mapping) VOICE_MAP.put(m[0], m[1]);
    }

    /** 获取音色选择菜单文字 */
    public static String getVoiceMenu() {
        return "请选择音色：\n" +
            "1. 女声-温暖\n2. 女声-活泼\n3. 男声-专业\n" +
            "4. 男声-阳光\n5. 男声-激情\n6. 男声-可爱\n\n" +
            "回复数字或音色名即可";
    }

    /** 根据用户输入匹配音色，匹配失败返回 null */
    public static String matchVoice(String input) {
        String key = input.trim().toLowerCase();
        return VOICE_MAP.getOrDefault(key, VOICE_MAP.getOrDefault(
            VOICE_MAP.keySet().stream().filter(k -> k.contains(key)).findFirst().orElse(""), null));
    }

    /** 默认音色 */
    public byte[] textToSpeech(String text) {
        return textToSpeech(text, "zh-CN-XiaoxiaoNeural");
    }

    /** 指定音色合成 */
    public byte[] textToSpeech(String text, String voice) {
        try {
            String clean = text.replaceAll("[\\p{So}\\p{Cn}]", "").trim();
            if (clean.isEmpty()) return null;
            System.out.println("[VoiceGen] 合成: " + clean + " 音色: " + voice);

            Process p = new ProcessBuilder(
                "edge-tts",
                "--voice", voice,
                "--text", clean,
                "--write-media", "-"
            ).start();

            ByteArrayOutputStream mp3 = new ByteArrayOutputStream();
            try (InputStream is = p.getInputStream()) { mp3.write(is.readAllBytes()); }

            String err;
            try (InputStream es = p.getErrorStream()) { err = new String(es.readAllBytes()); }

            int exit = p.waitFor();
            if (exit != 0 || mp3.size() == 0) {
                System.err.println("[VoiceGen] exit=" + exit + " err=" + err);
                return null;
            }

            System.out.println("[VoiceGen] MP3: " + mp3.size() + " 字节");
            return mp3.toByteArray();

        } catch (Exception e) {
            System.err.println("[VoiceGen] 失败: " + e.getMessage());
            return null;
        }
    }
}
