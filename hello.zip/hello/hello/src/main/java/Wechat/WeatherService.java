package Wechat;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.zip.GZIPInputStream;

/**
 * 天气查询服务 —— 查和风天气，内置城市映射表，支持 CLI 直接运行
 */
public class WeatherService {

    /** CLI 入口：java Wechat.WeatherService */
    public static void main(String[] args) {
        WeatherService service = new WeatherService();
        Scanner scanner = new Scanner(System.in);
        System.out.println("========== 天气查询工具 ==========");
        System.out.println("输入城市名，输入 q 退出\n");
        while (true) {
            System.out.print("城市名 > ");
            String city = scanner.nextLine().trim();
            if (city.isEmpty()) continue;
            if (city.equals("q") || city.equals("exit")) { System.out.println("再见！"); break; }
            System.out.println();
            System.out.println(service.queryWeatherText(city));
            System.out.println();
        }
        scanner.close();
    }

    private static final String WEATHER_API = Config.weatherApiUrl();
    private static final String API_KEY = Config.weatherApiKey();

    //两个转化工具，依赖里面带的
    private final RestTemplate restTemplate = new RestTemplate();
    private final ObjectMapper objectMapper = new ObjectMapper();


    private static void put(String name, String id) { cityMap.put(name, id); }
    private static void put(String name, String id, String pinyin) {
        cityMap.put(name, id); cityMap.put(pinyin, id);
    }

    // ==================== 公开方法 ====================

    public String queryWeatherText(String cityName) {
        try {
            String locationId = lookupCityId(cityName);
            if (locationId == null) {
                return "未识别城市\"" + cityName + "\"，请输入中文城市名或拼音";
            }
            String url = WEATHER_API + "?location="
                    + URLEncoder.encode(locationId, StandardCharsets.UTF_8)
                    + "&key=" + API_KEY;
            String json = httpGet(url);
            WeatherResponse wr = objectMapper.readValue(json, WeatherResponse.class);
            if (!"200".equals(wr.code) || wr.now == null) {
                return "查询失败，API返回code=" + wr.code;
            }
            return String.format(
                "【%s天气】\n🌡 温度: %s°C（体感 %s°C）\n🌤 天气: %s\n💧 湿度: %s%%\n🌬 风力: %s %s级",
                cityName, wr.now.temp, wr.now.feelsLike, wr.now.text,
                wr.now.humidity, wr.now.windDir, wr.now.windScale
            );
        } catch (Exception e) {
            return "查询失败: " + e.getMessage();
        }
    }

    // ==================== 内部方法 ====================

    private String lookupCityId(String input) {
        if (input == null) return null;
        if (input.matches("\\d{6,}")) return input;
        String id = cityMap.get(input);
        if (id != null) return id;
        return cityMap.get(input.toLowerCase());
    }

    private String httpGet(String url) throws Exception {
        ResponseEntity<byte[]> response = restTemplate.getForEntity(url, byte[].class);
        byte[] body = response.getBody();
        if (body == null || body.length == 0) throw new Exception("服务器未返回数据");
        if (body.length >= 2 && body[0] == (byte) 0x1F && body[1] == (byte) 0x8B) {
            GZIPInputStream gzis = new GZIPInputStream(new ByteArrayInputStream(body));
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            byte[] buf = new byte[4096]; int len;
            while ((len = gzis.read(buf)) != -1) baos.write(buf, 0, len);
            gzis.close();
            return baos.toString("UTF-8");
        }
        return new String(body, "UTF-8");
    }

    // ==================== 响应模型 ====================

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class WeatherResponse {
        public String code;
        public Now now;
        @JsonIgnoreProperties(ignoreUnknown = true)
        static class Now {
            public String temp, feelsLike, text, humidity, windDir, windScale;
        }
    }
    // ==================== 城市映射表 ====================
    private static final Map<String, String> cityMap = new HashMap<>();
    static {
        put("北京","101010100","beijing"); put("上海","101020100","shanghai");
        put("天津","101030100","tianjin"); put("重庆","101040100","chongqing");
        // 东北
        put("哈尔滨","101050101"); put("长春","101060101"); put("沈阳","101070101");
        put("大连","101070201"); put("吉林","101060201"); put("齐齐哈尔","101050201");
        put("牡丹江","101050301"); put("大庆","101050901"); put("漠河","101050703");
        // 华北
        put("石家庄","101090101"); put("保定","101090201"); put("唐山","101090501");
        put("邯郸","101091001"); put("秦皇岛","101091101"); put("承德","101090402");
        put("呼和浩特","101080101"); put("包头","101080201"); put("鄂尔多斯","101080701");
        put("太原","101100101"); put("大同","101100201");
        // 华东
        put("济南","101120101"); put("青岛","101120201"); put("烟台","101120501");
        put("威海","101121301"); put("潍坊","101120601"); put("淄博","101120301");
        put("南京","101190101"); put("苏州","101190401"); put("无锡","101190201");
        put("常州","101191101"); put("南通","101190501"); put("扬州","101190601");
        put("徐州","101190801"); put("镇江","101190301"); put("淮安","101190901");
        put("连云港","101191001"); put("宿迁","101191301"); put("盐城","101190701");
        put("泰州","101191201");
        put("杭州","101210101"); put("宁波","101210401"); put("温州","101210701");
        put("绍兴","101210501"); put("嘉兴","101210301"); put("湖州","101210201");
        put("金华","101210901"); put("台州","101210601"); put("舟山","101211101");
        put("合肥","101220101"); put("芜湖","101220301"); put("黄山","101221001");
        put("南昌","101240101"); put("九江","101240201"); put("赣州","101240701");
        put("福州","101230101"); put("厦门","101230201"); put("泉州","101230501");
        // 华中
        put("武汉","101200101"); put("宜昌","101200901"); put("襄阳","101200201");
        put("荆州","101200801"); put("郑州","101180101"); put("洛阳","101180901");
        put("开封","101180801"); put("南阳","101180701");
        put("长沙","101250101"); put("株洲","101250301"); put("岳阳","101251001");
        put("张家界","101251101"); put("衡阳","101250401");
        // 华南
        put("广州","101280101"); put("深圳","101280601"); put("东莞","101281601");
        put("佛山","101280801"); put("珠海","101280701"); put("中山","101281701");
        put("惠州","101280301"); put("汕头","101280501");
        put("南宁","101300101"); put("桂林","101300501"); put("柳州","101300301");
        put("北海","101301301");
        put("海口","101310101"); put("三亚","101310201");
        // 西南
        put("成都","101270101"); put("绵阳","101270401"); put("乐山","101271401");
        put("宜宾","101271101"); put("昆明","101290101"); put("大理","101290201");
        put("丽江","101291401"); put("贵阳","101260101"); put("遵义","101260201");
        put("拉萨","101140101"); put("日喀则","101140201");
        // 西北
        put("西安","101110101"); put("咸阳","101110200"); put("延安","101110300");
        put("兰州","101160101"); put("西宁","101150101"); put("银川","101170101");
        put("乌鲁木齐","101130101");
        // 港澳台
        put("香港","101320101","hongkong"); put("澳门","101330101","macau");
        put("台北","101340101","taipei"); put("高雄","101340201");
    }

}
