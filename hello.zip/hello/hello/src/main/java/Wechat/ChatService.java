package Wechat;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * DeepSeek AI 对话服务（Function Calling）
 *
 * 大模型自主选择工具：查天气 / 生图 / 生成语音
 */
public class ChatService {

    private static final String API_URL = Config.deepseekApiUrl();
    private static final String MODEL = "deepseek-chat";

    private final String apiKey;
    private final RestTemplate restTemplate = new RestTemplate();
    private final ObjectMapper objectMapper = new ObjectMapper();
    private static final int MAX_HISTORY = 20;
    private final Map<String, List<Message>> historyMap = new ConcurrentHashMap<>();

    // 工具实例
    private final WeatherService weatherService = new WeatherService();
    private final ImageGenerationService imageGenService = new ImageGenerationService();
    private final VoiceGenerationService voiceGenService = new VoiceGenerationService();

    // ==================== 工具定义 ====================

    private static final List<Map<String, Object>> TOOLS = List.of(
        Map.of("type", "function", "function", Map.of(
            "name", "query_weather",
            "description", "查询指定城市的实时天气",
            "parameters", Map.of("type", "object",
                "properties", Map.of("city", Map.of("type", "string", "description", "城市中文名，如北京"))
            , "required", List.of("city"))
        )),
        Map.of("type", "function", "function", Map.of(
            "name", "generate_image",
            "description", "根据文字描述生成一张图片",
            "parameters", Map.of("type", "object",
                "properties", Map.of("prompt", Map.of("type", "string", "description", "图片描述，如'一只可爱的橘猫'"))
            , "required", List.of("prompt"))
        )),
        Map.of("type", "function", "function", Map.of(
            "name", "generate_voice",
            "description", "把文字内容转成语音MP3文件发给用户",
            "parameters", Map.of("type", "object",
                "properties", Map.of("content", Map.of("type", "string", "description", "要转成语音的文字内容"))
            , "required", List.of("content"))
        ))
    );

    public ChatService() {
        String envKey = System.getenv("DEEPSEEK_API_KEY");//读取环境变量
        this.apiKey = (envKey != null && !envKey.isBlank()) ? envKey : Config.deepseekApiKey();
    }

    // ==================== 公开方法 ====================

    /** 对话入口，返回 ChatResult（可能含二进制数据） */
    public ChatResult chat(String userId, String message) {
        if (apiKey == null || apiKey.isBlank()) {//检查apikey
            return ChatResult.text("AI 对话功能未配置");
        }
        try {
            return doChat(userId, message);//返回发出消息
        } catch (Exception e) {
            System.err.println("DeepSeek 失败: " + e.getMessage());
            return ChatResult.text("抱歉，我暂时无法回复～");
        }
    }

    //把图片识别的结果注入到对话历史里，让后续聊天能引用这张图。
    public void injectImageContext(String userId, String imageDescription) {
        List<Message> history = getHistory(userId);
        history.add(new Message("user", "[用户发了一张图片]"));
        history.add(new Message("assistant", imageDescription));
        trim(history);
    }

    public void clearHistory(String userId) {
        historyMap.remove(userId);
    }

    // ==================== 核心 ====================

    private ChatResult doChat(String userId, String message) throws Exception {
        List<Message> history = getHistory(userId);// 1. 拿到这个用户的对话历史
        history.add(new Message("user", message)); // 2. 把用户刚发的消息追加进去
        byte[] generatedImage = null;// 3. 暂存工具生成的图片
        byte[] generatedVoice = null;// 4. 暂存工具生成的语音

        for (int round = 0; round < 3; round++) {
            ChatRequest req = buildRequest(history);
            String body = objectMapper.writeValueAsString(req);
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.setBearerAuth(apiKey);

            ResponseEntity<ChatResponse> resp = restTemplate.exchange(
                API_URL, HttpMethod.POST, new HttpEntity<>(body, headers), ChatResponse.class);
            ChatResponse cr = resp.getBody();
            if (cr == null || cr.choices == null || cr.choices.isEmpty())
                throw new RuntimeException("DeepSeek 返回空");

            Message assistantMsg = cr.choices.get(0).message;

            // 模型要调工具
            if (assistantMsg.tool_calls != null && !assistantMsg.tool_calls.isEmpty()) {
                history.add(assistantMsg);//加工具
                for (ToolCall tc : assistantMsg.tool_calls) {
                    System.out.println("[Chat] 工具: " + tc.function.name);
                    ToolResult tr = executeTool(tc);
                    history.add(new Message("tool", tr.text, tc.id, tc.function.name));
                    if (tr.image != null) generatedImage = tr.image;
                    if (tr.voice != null) generatedVoice = tr.voice;
                }
                continue;
            }

            // 最终回复
            String reply = assistantMsg.content != null ? assistantMsg.content : "";
            history.add(assistantMsg);
            trim(history);

            // 构建返回结果
            if (generatedImage != null) {
                return new ChatResult(reply, generatedImage, "image");
            }
            if (generatedVoice != null) {
                return new ChatResult(reply, generatedVoice, "voice");
            }
            return ChatResult.text(reply);
        }
        return ChatResult.text("处理超时");
    }

    // ==================== 工具执行 ====================

    @SuppressWarnings("unchecked")
    private ToolResult executeTool(ToolCall tc) {
        String name = tc.function.name;
        try {
            Map<String, Object> args = objectMapper.readValue(
                (String) tc.function.arguments, Map.class);

            switch (name) {
                case "query_weather": {
                    String city = (String) args.get("city");
                    if (city == null || city.isBlank()) return ToolResult.text("错误：未提供城市");
                    return ToolResult.text(weatherService.queryWeatherText(city));
                }
                case "generate_image": {
                    String prompt = (String) args.get("prompt");
                    if (prompt == null || prompt.isBlank()) return ToolResult.text("错误：未提供描述");
                    try {
                        byte[] img = imageGenService.generate(prompt);
                        return ToolResult.image(img);
                    } catch (ImageGenerationService.ContentSafetyException e) {
                        return ToolResult.text("内容安全审核未通过，请换个描述～");
                    } catch (Exception e) {
                        return ToolResult.text("图片生成失败: " + e.getMessage());
                    }
                }
                case "generate_voice": {
                    String content = (String) args.get("content");
                    if (content == null || content.isBlank()) return ToolResult.text("错误：未提供内容");
                    byte[] mp3 = voiceGenService.textToSpeech(content);
                    if (mp3 != null) return ToolResult.voice(mp3);
                    return ToolResult.text("语音生成失败");
                }
                default:
                    return ToolResult.text("未知工具: " + name);
            }
        } catch (Exception e) {
            return ToolResult.text("工具执行失败: " + e.getMessage());
        }
    }

    // ==================== 辅助 ====================

    private ChatRequest buildRequest(List<Message> history) {
        ChatRequest req = new ChatRequest();
        req.model = MODEL;
        req.messages = new ArrayList<>(history);
        req.temperature = 0.7;
        req.maxTokens = 1024;
        req.tools = TOOLS;
        req.toolChoice = "auto";
        return req;
    }

    private List<Message> getHistory(String userId) {
        List<Message> h = historyMap.computeIfAbsent(userId, k -> new ArrayList<>());
        if (h.isEmpty()) {
            h.add(new Message("system",
                "你是微信机器人助手，回复简洁在200字以内。可用工具：" +
                "query_weather 查天气、generate_image 画图、generate_voice 把文字转语音。"));
        }
        return h;
    }

    private void trim(List<Message> h) {
        while (h.size() > MAX_HISTORY + 1) h.remove(1);
    }

    // ==================== 返回类型 ====================

    public static class ChatResult {
        public final String text;
        public final byte[] binary;
        public final String binaryType; // "image" / "voice" / null

        ChatResult(String t, byte[] b, String type) { text = t; binary = b; binaryType = type; }
        public static ChatResult text(String t) { return new ChatResult(t, null, null); }
    }

    static class ToolResult {
        String text; byte[] image; byte[] voice;
        static ToolResult text(String t) { ToolResult r = new ToolResult(); r.text = t; return r; }
        static ToolResult image(byte[] b) { ToolResult r = new ToolResult(); r.text = "已生成图片"; r.image = b; return r; }
        static ToolResult voice(byte[] b) { ToolResult r = new ToolResult(); r.text = "已生成语音"; r.voice = b; return r; }
    }

    // ==================== JSON 模型 ====================

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class ChatRequest {
        public String model;
        public List<Message> messages;
        public double temperature;
        @JsonProperty("max_tokens") public int maxTokens;
        public List<Map<String, Object>> tools;
        @JsonProperty("tool_choice") public String toolChoice;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class ChatResponse { public List<Choice> choices; }

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class Choice { public Message message; }

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class Message {
        public String role, content;
        @JsonProperty("tool_calls") public List<ToolCall> tool_calls;
        @JsonProperty("tool_call_id") public String tool_call_id;
        public String name;
        Message() {}
        Message(String role, String content) { this.role = role; this.content = content; }
        Message(String role, String content, String tcId, String n) {
            this.role = role; this.content = content; this.tool_call_id = tcId; this.name = n;
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class ToolCall { public String id, type; @JsonProperty("function") public ToolFunction function; }

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class ToolFunction { public String name; public Object arguments; }
}
