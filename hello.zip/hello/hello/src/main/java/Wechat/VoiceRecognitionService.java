package Wechat;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.web.client.RestTemplate;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.*;

/**
 * 阿里云 语音服务
 *
 * ASR: Qwen-Omni（百炼 OpenAI 兼容接口 + SILK 解码）
 * TTS: CosyVoice-V1（百炼 /speech 端点，返回原始音频）
 */
public class VoiceRecognitionService {

    private static final String OMNI_URL = Config.aliyunApiUrl();
    private static final String TTS_URL  = Config.aliyunTtsUrl();
    private static final String API_KEY  = Config.aliyunApiKey();

    private final RestTemplate restTemplate = new RestTemplate();
    private final ObjectMapper objectMapper = new ObjectMapper();

    // ==================== ASR：语音 → 文字 ====================

    public String speechToText(byte[] audioBytes, String format, int sampleRate) {
        try {
            System.out.println("[ASR] 收到: " + audioBytes.length + "字节 sr=" + sampleRate);

            // Step 1: SILK → WAV
            byte[] wav = decodeSilkToWav(audioBytes, sampleRate);
            System.out.println("[ASR] WAV: " + wav.length + "字节");

            // Step 2: Base64
            String b64 = Base64.getEncoder().encodeToString(wav);

            // Step 3: Qwen-Omni 请求
            Map<String, Object> req = new LinkedHashMap<>();
            req.put("model", "qwen-omni-turbo");
            req.put("stream", true);
            req.put("modalities", List.of("text"));
            req.put("messages", List.of(Map.of(
                "role", "user",
                "content", List.of(
                    Map.of("type", "input_audio",
                           "input_audio", Map.of("data", "data:audio/wav;base64," + b64, "format", "wav")),
                    Map.of("type", "text", "text", "请将这段语音转写成文字，只输出转写文字，不加解释。")
                )
            )));

            String body = objectMapper.writeValueAsString(req);
            System.out.println("[ASR] 请求: " + body.length() + "字符");

            // Step 4: SSE 流式请求
            String text = ssePost(body);
            System.out.println("[ASR] 结果: " + text);
            return text != null && !text.isBlank() ? text.trim() : "";

        } catch (Exception e) {
            System.err.println("[ASR] 失败: " + e.getMessage());
            return null;
        }
    }

    // ==================== SSE POST ====================

    private String ssePost(String jsonBody) throws IOException {
        HttpURLConnection conn = (HttpURLConnection) new URL(OMNI_URL).openConnection();
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("Authorization", "Bearer " + API_KEY);
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(30000);

        try (OutputStream os = conn.getOutputStream()) {
            os.write(jsonBody.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        }

        int status = conn.getResponseCode();
        InputStream in = status >= 400 ? conn.getErrorStream() : conn.getInputStream();
        if (status >= 400) {
            String err = new String(in.readAllBytes());
            throw new IOException("HTTP " + status + ": " + err);
        }

        StringBuilder sb = new StringBuilder();
        BufferedReader r = new BufferedReader(new InputStreamReader(in));
        String line;
        while ((line = r.readLine()) != null) {
            if (line.startsWith("data: ") && !line.equals("data: [DONE]")) {
                try {
                    @SuppressWarnings("unchecked")
                    Map<String, Object> chunk = objectMapper.readValue(line.substring(6), Map.class);
                    List<Map<String, Object>> choices = (List<Map<String, Object>>) chunk.get("choices");
                    if (choices != null && !choices.isEmpty()) {
                        Map<String, Object> delta = (Map<String, Object>) choices.get(0).get("delta");
                        if (delta != null && delta.get("content") instanceof String) {
                            sb.append(delta.get("content"));
                        }
                    }
                } catch (Exception ignore) {}
            }
        }
        conn.disconnect();
        return sb.toString();
    }

    // ==================== SILK → WAV ====================

    private byte[] decodeSilkToWav(byte[] silkBytes, int sampleRate) throws IOException, InterruptedException {
        File tmp = File.createTempFile("wx-voice-", ".silk");
        try {
            java.nio.file.Files.write(tmp.toPath(), silkBytes);

            String script = findScript();
            Process p = new ProcessBuilder("python3", script, String.valueOf(sampleRate))
                .redirectInput(tmp)
                .start();

            ByteArrayOutputStream wavOut = new ByteArrayOutputStream();
            try (InputStream is = p.getInputStream()) { wavOut.write(is.readAllBytes()); }

            String err;
            try (InputStream es = p.getErrorStream()) { err = new String(es.readAllBytes()); }

            int exit = p.waitFor();
            if (exit != 0) throw new IOException("pilk exit=" + exit + ": " + err);
            if (wavOut.size() == 0) throw new IOException("pilk 输出为空");
            return wavOut.toByteArray();
        } finally {
            tmp.delete();
        }
    }

    private String findScript() {
        for (String path : new String[]{"decode_silk.py", "../decode_silk.py"}) {
            if (new File(path).exists()) return new File(path).getAbsolutePath();
        }
        return "decode_silk.py";
    }

    // ==================== TTS：文字 → 语音（Edge TTS 免费） ====================

    public byte[] textToSpeech(String text) {
        try {
            // 去掉 emoji
            String clean = text.replaceAll("[\\p{So}\\p{Cn}]", "").trim();
            if (clean.isEmpty()) return null;
            System.out.println("[TTS] 合成: " + clean);

            // edge-tts: 通过 stdin 传文字，stdout 输出 MP3
            Process p = new ProcessBuilder(
                "edge-tts",
                "--voice", "zh-CN-XiaoxiaoNeural",
                "--text", clean,
                "--write-media", "-"
            ).start();

            ByteArrayOutputStream mp3 = new ByteArrayOutputStream();
            try (InputStream is = p.getInputStream()) {
                mp3.write(is.readAllBytes());
            }

            String err;
            try (InputStream es = p.getErrorStream()) { err = new String(es.readAllBytes()); }

            int exit = p.waitFor();
            if (exit != 0 || mp3.size() == 0) {
                System.err.println("[TTS] edge-tts exit=" + exit + " err=" + err);
                return null;
            }

            System.out.println("[TTS] MP3: " + mp3.size() + "字节");
            return mp3.toByteArray();

        } catch (Exception e) {
            System.err.println("[TTS] 失败: " + e.getMessage());
            return null;
        }
    }
}
