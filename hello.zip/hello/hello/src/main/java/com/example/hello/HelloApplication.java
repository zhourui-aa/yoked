package com.example.hello;

import Wechat.WeChatBot;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class HelloApplication {

	public static void main(String[] args) {
		SpringApplication.run(HelloApplication.class, args);
	}

	/**
	 * Spring Boot 启动后自动拉起微信机器人
	 */
	@Bean
	CommandLineRunner startWeChatBot() {
		return args -> {
			System.out.println("🤖 正在启动微信机器人...");
			new Thread(() -> {
				try {
					WeChatBot.main(args);
				} catch (Exception e) {
					System.err.println("微信机器人启动失败: " + e.getMessage());
					e.printStackTrace();
				}
			}, "wechat-bot").start();
		};
	}

}
