#!/usr/bin/env python3
"""将 SILK 音频（stdin）解码为 WAV（stdout）"""
import sys, io, wave, tempfile, os
import pilk

silk_data = sys.stdin.buffer.read()
sample_rate = int(sys.argv[1]) if len(sys.argv) > 1 else 24000

# pilk.decode(silk路径, pcm输出路径, 采样率) → 写 PCM 文件
silk_file = tempfile.NamedTemporaryFile(suffix='.silk', delete=False)
pcm_file = tempfile.NamedTemporaryFile(suffix='.pcm', delete=False)
try:
    silk_file.write(silk_data)
    silk_file.close()
    pcm_file.close()

    pilk.decode(silk_file.name, pcm_file.name, sample_rate)

    # 读 PCM 数据
    with open(pcm_file.name, 'rb') as f:
        pcm = f.read()
finally:
    os.unlink(silk_file.name)
    os.unlink(pcm_file.name)

# PCM → WAV（加 44 字节 WAV 头）
buf = io.BytesIO()
with wave.open(buf, 'wb') as w:
    w.setnchannels(1)
    w.setsampwidth(2)          # 16-bit
    w.setframerate(sample_rate)
    w.writeframes(pcm)

sys.stdout.buffer.write(buf.getvalue())
